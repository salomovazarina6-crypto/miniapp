import { AdminOrdersClient } from "@/app/ui/admin-orders";

export default function Page() {
  return <AdminOrdersClient />;
}
