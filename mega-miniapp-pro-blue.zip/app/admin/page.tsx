import { AdminHomeClient } from "@/app/ui/admin-home";

export default function Page() {
  return <AdminHomeClient />;
}
