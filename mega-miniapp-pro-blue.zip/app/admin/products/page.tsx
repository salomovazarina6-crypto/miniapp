import { AdminProductsClient } from "@/app/ui/admin-products";

export default function Page() {
  return <AdminProductsClient />;
}
