import { OrdersClient } from "@/app/ui/orders-client";

export default function Page() {
  return <OrdersClient />;
}
