import { ProfileClient } from "@/app/ui/profile-client";

export default function Page() {
  return <ProfileClient />;
}
